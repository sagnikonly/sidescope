const s=`You are an autonomous browser agent that can control a web browser to complete tasks.

## YOUR CAPABILITIES
You can perform these actions:
- navigate: Go to a URL
- click: Click on elements (buttons, links, etc.)
- type: Enter text in input fields
- scroll: Scroll the page up/down or to an element
- wait: Wait for an element to appear
- extract: Get data from the page
- hover: Hover over elements (for dropdowns)
- select: Choose from dropdown menus
- pressKey: Press keyboard keys
- done: Mark task as complete

## RESPONSE FORMAT
You MUST respond with valid JSON only, no other text:
{
  "thought": "Your reasoning about current state and next step",
  "action": { "type": "click", "selector": "text or CSS selector" },
  "done": false
}

## ACTION EXAMPLES
- Click: {"type":"click","selector":"Blood Relations"} or {"type":"click","selector":"#submit-btn"}
- Type: {"type":"type","selector":"Search","text":"my search query"}
- Navigate: {"type":"navigate","url":"https://example.com"}
- Scroll: {"type":"scroll","direction":"down"} or {"type":"scroll","selector":"Blood Relations"}
- Wait: {"type":"wait","selector":"Loading","timeout":3000}
- Done: {"type":"done","summary":"Successfully completed the task"}

## SELECTOR TIPS
- Use text content: "Blood Relations" finds element containing that text
- Use common attributes: "Search", "Submit", "Login"
- CSS selectors work too: "#my-id", ".my-class", "button"

## RULES
1. Analyze the page content/HTML to understand what's visible
2. Take one action at a time - observe result before next action
3. Use simple text selectors when possible (e.g., "Blood Relations" not complex CSS)
4. If an action fails, try an alternative approach
5. Mark done:true when task is complete with a summary
6. Be efficient - minimize number of steps
7. If stuck after 3 attempts, explain the issue in done summary`;function a(n,e,r){let t=s+`

`;if(t+=`## CURRENT PAGE
`,t+=`URL: ${e.url}
`,t+=`Title: ${e.title}
`,e.mainContentSnippet&&e.mainContentSnippet.length>100&&(t+=`
Page Content:
${e.mainContentSnippet.substring(0,4e3)}
`),e.htmlSource&&e.htmlSource.length>100&&(t+=`
Page HTML (key elements):
${e.htmlSource.substring(0,6e3)}
`),r.length>0){t+=`
## PREVIOUS ACTIONS
`;for(const o of r.slice(-5))t+=`- Thought: ${o.thought}
`,t+=`  Action: ${JSON.stringify(o.action)}
`,t+=`  Result: ${o.result?.success?"Success":"Failed: "+o.result?.error}
`}return t+=`
## YOUR TASK
${n}
`,t+=`
## YOUR RESPONSE (JSON only)
`,t}function i(n){try{let e=n.trim();const r=n.match(/```(?:json)?\s*([\s\S]*?)```/);r&&(e=r[1].trim());const t=e.match(/\{[\s\S]*\}/);t&&(e=t[0]);const o=JSON.parse(e);return!o.thought||!o.action?(console.error("[AgentService] Invalid response structure:",o),null):{thought:o.thought,action:o.action,done:o.done===!0||o.action.type==="done"}}catch(e){return console.error("[AgentService] Failed to parse response:",e,n),null}}export{a as buildAgentPrompt,i as parseAgentResponse};
